(() => {
  const $ = (id) => document.getElementById(id);
  const qs = (sel) => document.querySelector(sel);
  const qsa = (sel) => document.querySelectorAll(sel);

  const state = {
    user: null,
    settings: {
      mode: "normal",
      targetScore: 12,
      totalScore: 12,
      engine: "lite",
      autoRun: true,
      soundOn: false,
    },
    usage: { used: 0, limit: 12 },
  };

  function showToast(text, type) {
    const existing = qs(".toast");
    if (existing) existing.remove();
    const t = document.createElement("div");
    t.className = "toast " + (type || "");
    t.textContent = text;
    document.querySelector(".app").appendChild(t);
    requestAnimationFrame(() => t.classList.add("show"));
    setTimeout(() => {
      t.classList.remove("show");
      setTimeout(() => t.remove(), 300);
    }, 2400);
  }

  function setStatus(online) {
    const el = $("status");
    if (online) {
      el.textContent = "online";
      el.classList.add("online");
    } else {
      el.textContent = "offline";
      el.classList.remove("online");
    }
  }

  function switchView(name) {
    qsa(".view").forEach((v) => v.classList.add("hidden"));
    $("view-" + name).classList.remove("hidden");
  }

  function bindAuthTabs() {
    qsa(".tab").forEach((tab) => {
      tab.addEventListener("click", () => {
        qsa(".tab").forEach((t) => t.classList.remove("active"));
        tab.classList.add("active");
        const target = tab.dataset.tab;
        $("form-login").classList.toggle("hidden", target !== "login");
        $("form-register").classList.toggle("hidden", target !== "register");
      });
    });
  }

  async function handleLogin() {
    const email = $("login-email").value.trim();
    const pass = $("login-pass").value;
    const err = $("login-error");
    err.textContent = "";

    if (!email || !pass) {
      err.textContent = "Заполните все поля";
      return;
    }

    const btn = $("btn-login");
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span>';

    try {
      const res = await window.tvAuth.login(email, pass);
      state.user = res.user;
      await loadMainView();
      switchView("main");
      showToast("Добро пожаловать", "success");
    } catch (e) {
      err.textContent = e.message || "Ошибка входа";
    } finally {
      btn.disabled = false;
      btn.textContent = "Войти";
    }
  }

  async function handleRegister() {
    const email = $("reg-email").value.trim();
    const name = $("reg-name").value.trim();
    const pass = $("reg-pass").value;
    const pass2 = $("reg-pass2").value;
    const err = $("reg-error");
    err.textContent = "";

    if (!email || !name || !pass) {
      err.textContent = "Заполните все поля";
      return;
    }
    if (pass.length < 6) {
      err.textContent = "Пароль минимум 6 символов";
      return;
    }
    if (pass !== pass2) {
      err.textContent = "Пароли не совпадают";
      return;
    }

    const btn = $("btn-register");
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span>';

    try {
      const res = await window.tvAuth.register(email, name, pass);
      state.user = res.user;
      await loadMainView();
      switchView("main");
      showToast("Аккаунт создан", "success");
    } catch (e) {
      err.textContent = e.message || "Ошибка регистрации";
    } finally {
      btn.disabled = false;
      btn.textContent = "Создать аккаунт";
    }
  }

  function paintUser() {
    $("user-name").textContent = state.user.name || "Пользователь";
    $("user-email").textContent = state.user.email;
    const plan = state.user.plan;
    const isPaid = plan === "premium" || plan === "ultimate";
    const isUltimate = plan === "ultimate";
    const badge = $("plan-badge");
    badge.textContent = isUltimate ? "ULTIMATE" : (plan === "premium" ? "PREMIUM" : "FREE");
    badge.classList.toggle("premium", isPaid);
    badge.classList.toggle("ultimate", isUltimate);
    qsa("#engine-select option").forEach((opt) => {
      if (opt.value === "pro") opt.disabled = !isPaid;
      if (opt.value === "ultra") opt.disabled = !isUltimate;
    });
    $("btn-upgrade").classList.toggle("hidden", isPaid);
  }

  function paintUsage() {
    const { used, limit } = state.usage;
    const pct = Math.min(100, (used / limit) * 100);
    const fill = $("usage-fill");
    fill.style.width = pct + "%";
    fill.classList.toggle("warn", pct >= 75);
    const isUltimate = state.user.plan === "ultimate";
    $("usage-text").textContent = isUltimate
      ? `${used} вопросов · безлимит`
      : `${used} / ${limit} вопросов сегодня`;
  }

  function paintSettings() {
    qsa('input[name="mode"]').forEach((r) => {
      r.checked = r.value === state.settings.mode;
    });
    $("target-score").value = state.settings.targetScore;
    $("total-score").value = state.settings.totalScore;
    $("engine-select").value = state.settings.engine;
    $("auto-run").checked = state.settings.autoRun;
    $("sound-on").checked = state.settings.soundOn;
  }

  function bindSettings() {
    qsa('input[name="mode"]').forEach((r) => {
      r.addEventListener("change", () => {
        state.settings.mode = r.value;
        saveSettings();
      });
    });
    $("target-score").addEventListener("change", () => {
      let v = parseInt($("target-score").value, 10) || 1;
      const total = parseInt($("total-score").value, 10) || 12;
      if (v < 1) v = 1;
      if (v > total) v = total;
      $("target-score").value = v;
      state.settings.targetScore = v;
      saveSettings();
    });
    $("total-score").addEventListener("change", () => {
      let v = parseInt($("total-score").value, 10) || 12;
      if (v < 1) v = 1;
      $("total-score").value = v;
      state.settings.totalScore = v;
      if (state.settings.targetScore > v) {
        state.settings.targetScore = v;
        $("target-score").value = v;
      }
      saveSettings();
    });
    $("btn-auto-score").addEventListener("click", () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs[0]) return;
        chrome.tabs.sendMessage(tabs[0].id, { type: "DETECT_TEST" }, (resp) => {
          if (chrome.runtime.lastError) {
            showToast("Откройте страницу теста", "error");
            return;
          }
          if (resp && resp.total) {
            $("total-score").value = resp.total;
            state.settings.totalScore = resp.total;
            state.settings.targetScore = resp.total;
            $("target-score").value = resp.total;
            saveSettings();
            showToast("Найдено " + resp.total + " вопросов", "success");
          } else {
            showToast("Тест не обнаружен", "error");
          }
        });
      });
    });
    $("engine-select").addEventListener("change", () => {
      state.settings.engine = $("engine-select").value;
      saveSettings();
    });
    $("auto-run").addEventListener("change", () => {
      state.settings.autoRun = $("auto-run").checked;
      saveSettings();
    });
    $("sound-on").addEventListener("change", () => {
      state.settings.soundOn = $("sound-on").checked;
      saveSettings();
    });
    $("btn-scan").addEventListener("click", scanPage);
    $("btn-upgrade").addEventListener("click", () => {
      chrome.tabs.create({ url: "https://testvision.app/pricing" });
    });
    $("link-site").addEventListener("click", (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: "https://testvision.app" });
    });
    $("link-logout").addEventListener("click", async (e) => {
      e.preventDefault();
      await window.tvAuth.logout();
      state.user = null;
      switchView("auth");
      setStatus(false);
    });
  }

  async function saveSettings() {
    await chrome.storage.local.set({ tvSettings: state.settings });
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      chrome.tabs.sendMessage(tabs[0].id, {
        type: "SETTINGS_UPDATE",
        settings: state.settings,
      }, () => void chrome.runtime.lastError);
    });
  }

  async function loadSettings() {
    const data = await chrome.storage.local.get("tvSettings");
    if (data.tvSettings) Object.assign(state.settings, data.tvSettings);
  }

  function scanPage() {
    const btn = $("btn-scan");
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span>';
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) {
        btn.disabled = false;
        btn.textContent = "Сканировать страницу";
        return;
      }
      chrome.tabs.sendMessage(tabs[0].id, {
        type: "RUN_SCAN",
        settings: state.settings,
      }, (resp) => {
        btn.disabled = false;
        btn.textContent = "Сканировать страницу";
        if (chrome.runtime.lastError) {
          showToast("Откройте сайт с тестом", "error");
          return;
        }
        if (resp && resp.ok) {
          showToast("Найдено " + resp.count + " ответов", "success");
          loadUsage();
        } else if (resp && resp.error) {
          showToast(resp.error, "error");
        } else {
          showToast("Не удалось распознать тест", "error");
        }
      });
    });
  }

  async function loadUsage() {
    try {
      const usage = await window.tvApi.getUsage();
      state.usage = usage;
      paintUsage();
    } catch {}
  }

  async function loadMainView() {
    paintUser();
    await loadSettings();
    paintSettings();
    await loadUsage();
    setStatus(true);
  }

  async function init() {
    bindAuthTabs();
    $("btn-login").addEventListener("click", handleLogin);
    $("btn-register").addEventListener("click", handleRegister);
    bindSettings();
    [$("login-pass"), $("login-email")].forEach((el) => {
      el.addEventListener("keydown", (e) => {
        if (e.key === "Enter") handleLogin();
      });
    });
    [$("reg-email"), $("reg-name"), $("reg-pass"), $("reg-pass2")].forEach((el) => {
      el.addEventListener("keydown", (e) => {
        if (e.key === "Enter") handleRegister();
      });
    });

    const session = await window.tvAuth.getSession();
    if (session && session.user) {
      state.user = session.user;
      await loadMainView();
      switchView("main");
    } else {
      switchView("auth");
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
