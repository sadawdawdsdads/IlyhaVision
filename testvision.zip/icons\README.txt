PNG-иконки генерируются из icon.svg командой:

  cd build
  npm install
  npm run icons

Результат: icon16.png, icon32.png, icon48.png, icon96.png, icon128.png в этой папке.
До генерации manifest.json будет ругаться на отсутствие PNG.
