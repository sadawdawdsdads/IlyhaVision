(() => {
  if (window.__tvNaurokInjected) return;
  window.__tvNaurokInjected = true;

  const D = window.tvDom;
  const S = window.tvScore;

  const state = {
    settings: null,
    running: false,
    hud: null,
    hudVisible: true,
    answersCache: new Map(),
    targetByQuestionIndex: null,
    autoMode: true,
    totalQuestions: 0,
    currentIndex: 0,
    correctCount: 0,
    wrongCount: 0,
    observer: null,
  };

  function detectTotalAndIndex() {
    const cur = document.querySelector(".currentActiveQuestion");
    const total = document.querySelector('[ng-bind="test.document.questions"]');
    const c = cur ? parseInt(D.cleanText(cur.textContent), 10) : 0;
    const t = total ? parseInt(D.cleanText(total.textContent), 10) : 0;
    return { current: c || 0, total: t || 0 };
  }

  function parseCurrentQuestion() {
    const block = document.querySelector(".test-container-inner") ||
                  document.querySelector(".test-screen") || document.body;

    const textNode = document.querySelector(".test-content-text-inner") ||
                     document.querySelector('[ng-bind-html="renderHtml(test.question.content)"]');
    const text = textNode ? D.visibleText(textNode).slice(0, 1500) : "";

    const optsWrap = document.querySelector(".test-options-grid") ||
                     document.querySelector(".test-question-options");
    if (!optsWrap) return null;

    const optionItems = Array.from(optsWrap.querySelectorAll(".question-option-inner"));
    if (optionItems.length < 2) return null;

    const options = optionItems.map((el) => {
      const c = el.querySelector(".question-option-inner-content");
      return D.visibleText(c || el).slice(0, 400);
    });

    const images = D.imagesIn(block).slice(0, 3);
    const detect = detectTotalAndIndex();
    state.totalQuestions = detect.total || state.totalQuestions;
    state.currentIndex = detect.current || state.currentIndex;
    const id = D.hash(text + "|" + options.join("|"));
    return {
      id,
      index: state.currentIndex,
      element: block,
      optionElements: optionItems,
      text,
      images,
      options,
    };
  }

  function buildHud() {
    if (state.hud) return state.hud;
    const root = document.createElement("div");
    root.className = "tv-hud";
    root.innerHTML = `
      <div class="tv-hud-head" data-drag>
        <div class="tv-hud-title"><div class="tv-hud-dot"></div>IlyhaVision</div>
        <div class="tv-hud-controls">
          <button class="tv-hud-icon" data-act="solve" title="Решить (R Shift)">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M13 2L3 14h7l-1 8 10-12h-7l1-8z"/></svg>
          </button>
          <button class="tv-hud-icon" data-act="close" title="Скрыть">×</button>
        </div>
      </div>
      <div class="tv-hud-body">
        <div class="tv-hud-stats">
          <div class="tv-stat">
            <div class="tv-stat-value" data-k="current">—</div>
            <div class="tv-stat-label">текущий</div>
          </div>
          <div class="tv-stat-sep">/</div>
          <div class="tv-stat">
            <div class="tv-stat-value" data-k="total">0</div>
            <div class="tv-stat-label">всего</div>
          </div>
        </div>
        <div class="tv-progress"><div class="tv-progress-fill"></div></div>
        <div class="tv-hud-mini">
          <span class="tv-mini-correct"><b data-k="correct">0</b> ✓</span>
          <span class="tv-mini-wrong"><b data-k="wrong">0</b> ✗</span>
          <span class="tv-mini-target">цель <b data-k="target">12</b></span>
        </div>
      </div>`;
    document.body.appendChild(root);
    root.querySelector('[data-act="solve"]').addEventListener("click", () => run(true));
    root.querySelector('[data-act="close"]').addEventListener("click", () => toggleHud(false));
    makeDraggable(root, root.querySelector("[data-drag]"));
    state.hud = root;
    restoreHudPosition();
    return root;
  }

  function makeDraggable(el, handle) {
    let dragging = false, startX = 0, startY = 0, origX = 0, origY = 0;
    handle.addEventListener("mousedown", (e) => {
      if (e.target.closest(".tv-hud-icon")) return;
      dragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = el.getBoundingClientRect();
      origX = rect.left;
      origY = rect.top;
      el.style.right = "auto";
      el.style.bottom = "auto";
      el.style.left = origX + "px";
      el.style.top = origY + "px";
      e.preventDefault();
    });
    document.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      const newX = Math.max(0, Math.min(window.innerWidth - el.offsetWidth, origX + dx));
      const newY = Math.max(0, Math.min(window.innerHeight - el.offsetHeight, origY + dy));
      el.style.left = newX + "px";
      el.style.top = newY + "px";
    });
    document.addEventListener("mouseup", () => {
      if (!dragging) return;
      dragging = false;
      saveHudPosition();
    });
  }

  function saveHudPosition() {
    if (!state.hud) return;
    const rect = state.hud.getBoundingClientRect();
    chrome.storage.local.set({
      tvHudPos: { left: rect.left, top: rect.top },
    });
  }

  async function restoreHudPosition() {
    if (!state.hud) return;
    const data = await chrome.storage.local.get("tvHudPos");
    if (data.tvHudPos) {
      state.hud.style.right = "auto";
      state.hud.style.bottom = "auto";
      state.hud.style.left = data.tvHudPos.left + "px";
      state.hud.style.top = data.tvHudPos.top + "px";
    }
  }

  function toggleHud(force) {
    if (!state.hud) buildHud();
    const visible = force === undefined ? !state.hudVisible : force;
    state.hudVisible = visible;
    state.hud.classList.toggle("tv-hud-hidden", !visible);
  }

  function updateHud(patch) {
    if (!state.hud) buildHud();
    Object.entries(patch || {}).forEach(([k, v]) => {
      const el = state.hud.querySelector(`[data-k="${k}"]`);
      if (el) el.textContent = v;
    });
  }

  function setProgress(p) {
    if (!state.hud) return;
    const fill = state.hud.querySelector(".tv-progress-fill");
    if (fill) fill.style.width = Math.max(0, Math.min(100, p)) + "%";
  }

  function showToast(text, kind) {
    const t = document.createElement("div");
    t.className = "tv-toast tv-toast-" + (kind || "info");
    t.textContent = text;
    document.body.appendChild(t);
    requestAnimationFrame(() => t.classList.add("tv-toast-show"));
    setTimeout(() => {
      t.classList.remove("tv-toast-show");
      setTimeout(() => t.remove(), 400);
    }, 2400);
  }

  let audioCtx = null;
  function beep(freq, duration) {
    if (!state.settings || !state.settings.soundOn) return;
    try {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.frequency.value = freq;
      osc.type = "sine";
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      gain.gain.setValueAtTime(0, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0.08, audioCtx.currentTime + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
      osc.start(audioCtx.currentTime);
      osc.stop(audioCtx.currentTime + duration);
    } catch {}
  }

  function applyMode() {
    document.documentElement.classList.toggle(
      "tv-stealth",
      state.settings && state.settings.mode === "stealth"
    );
  }

  function clearMarks() {
    document.querySelectorAll(".tv-mark").forEach((el) => {
      el.classList.remove("tv-mark", "tv-mark-correct", "tv-mark-wrong");
    });
  }

  function markOption(el, correct) {
    if (!el) return;
    el.classList.add("tv-mark", correct ? "tv-mark-correct" : "tv-mark-wrong");
  }

  function sendBg(type, payload) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type, payload }, (resp) => resolve(resp || {}));
    });
  }

  async function solveOne(q) {
    const cached = state.answersCache.get(q.id);
    if (cached) return cached;
    const payload = {
      site: "naurok",
      engine: state.settings.engine,
      questions: [{ id: q.id, text: q.text, options: q.options, images: q.images }],
    };
    const hasImages = q.images && q.images.length;
    const resp = await sendBg(hasImages ? "BG_VISION" : "BG_SOLVE", payload);
    if (!resp.ok) {
      if (resp.status === 402) throw new Error("Лимит запросов исчерпан");
      throw new Error(resp.error || "Ошибка AI");
    }
    const ans = (resp.data.answers || []).find((a) => a.id === q.id);
    if (ans) state.answersCache.set(q.id, ans);
    return ans;
  }

  function buildScorePlan(total) {
    const target = Math.min(state.settings.targetScore || 12, total);
    const order = [];
    for (let i = 0; i < total; i++) order.push(i);
    for (let i = order.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [order[i], order[j]] = [order[j], order[i]];
    }
    const correctSet = new Set(order.slice(0, target));
    const map = new Map();
    for (let i = 0; i < total; i++) map.set(i, correctSet.has(i));
    return map;
  }

  function shouldBeCorrectForIndex(idx, total) {
    if (!state.targetByQuestionIndex || state.targetByQuestionIndex.size !== total) {
      state.targetByQuestionIndex = buildScorePlan(total);
    }
    return state.targetByQuestionIndex.get(idx) !== false;
  }

  async function run(manual) {
    if (state.running) return { ok: false, error: "уже работает" };
    state.running = true;
    clearMarks();
    try {
      const q = parseCurrentQuestion();
      if (!q) {
        if (manual) showToast("Вопрос не найден", "error");
        return { ok: false, error: "no question" };
      }

      const detect = detectTotalAndIndex();
      state.totalQuestions = detect.total || state.totalQuestions || 12;
      state.currentIndex = detect.current || state.currentIndex || 1;

      const ans = await solveOne(q);
      if (!ans || typeof ans.correctIndex !== "number") {
        if (manual) showToast("AI не вернул ответ", "error");
        return { ok: false, error: "no answer" };
      }

      const qIdx = state.currentIndex - 1;
      const shouldBeCorrect = shouldBeCorrectForIndex(qIdx, state.totalQuestions);
      const targetIdx = shouldBeCorrect
        ? ans.correctIndex
        : S.pickWrongOption(q.options, ans.correctIndex);
      const optEl = q.optionElements[targetIdx];
      markOption(optEl, shouldBeCorrect);

      if (shouldBeCorrect) state.correctCount++;
      else state.wrongCount++;

      updateHud({
        current: state.currentIndex,
        total: state.totalQuestions,
        correct: state.correctCount,
        wrong: state.wrongCount,
        target: state.settings.targetScore,
      });
      setProgress((state.currentIndex / state.totalQuestions) * 100);

      beep(shouldBeCorrect ? 880 : 440, 0.12);
      return { ok: true, count: 1 };
    } catch (e) {
      if (manual) showToast(e.message || "Ошибка", "error");
      beep(220, 0.2);
      return { ok: false, error: e.message };
    } finally {
      state.running = false;
    }
  }

  let scheduledTimer = null;
  function scheduleAuto() {
    if (scheduledTimer) clearTimeout(scheduledTimer);
    scheduledTimer = setTimeout(() => {
      if (state.autoMode) run(false);
    }, 600);
  }

  function startObserver() {
    if (state.observer) return;
    const target = document.querySelector(".test-container, .test-screen, body") || document.body;
    let lastIndex = state.currentIndex;
    state.observer = new MutationObserver(() => {
      const detect = detectTotalAndIndex();
      if (detect.current && detect.current !== lastIndex) {
        lastIndex = detect.current;
        state.currentIndex = detect.current;
        state.totalQuestions = detect.total || state.totalQuestions;
        updateHud({ current: state.currentIndex, total: state.totalQuestions });
        if (state.autoMode) scheduleAuto();
      }
    });
    state.observer.observe(target, { childList: true, subtree: true, characterData: true });
  }

  function setupHotkey() {
    document.addEventListener("keydown", (e) => {
      if (e.key === "Shift" && e.location === KeyboardEvent.DOM_KEY_LOCATION_RIGHT) {
        toggleHud();
        e.preventDefault();
      }
    }, true);
  }

  async function loadSettings() {
    const data = await chrome.storage.local.get("tvSettings");
    state.settings = data.tvSettings || {
      mode: "normal",
      targetScore: 12,
      totalScore: 12,
      engine: "lite",
      hudOn: true,
      soundOn: false,
    };
    if (!state.settings.totalScore) state.settings.totalScore = 12;
    state.targetByQuestionIndex = null;
    applyMode();
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "DETECT_TEST") {
      const det = detectTotalAndIndex();
      sendResponse({ total: det.total, current: det.current });
      return;
    }
    if (msg.type === "RUN_SCAN") {
      if (msg.settings) state.settings = msg.settings;
      applyMode();
      run(true).then((r) => sendResponse(r));
      return true;
    }
    if (msg.type === "SETTINGS_UPDATE") {
      state.settings = msg.settings;
      applyMode();
      state.targetByQuestionIndex = null;
      if (state.hud) state.hud.classList.toggle("tv-hud-hidden", state.settings.hudOn === false);
      sendResponse({ ok: true });
      return;
    }
  });

  (async () => {
    await loadSettings();
    if (state.settings.hudOn !== false) {
      buildHud();
    }
    setupHotkey();
    const det = detectTotalAndIndex();
    state.totalQuestions = det.total;
    state.currentIndex = det.current;
    updateHud({
      current: det.current || "—",
      total: det.total || 0,
      correct: 0,
      wrong: 0,
      target: state.settings.targetScore,
    });
    startObserver();
    setTimeout(() => {
      if (state.autoMode && parseCurrentQuestion()) run(false);
    }, 1500);
  })();
})();
