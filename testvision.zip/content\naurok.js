(() => {
  if (window.__tvNaurokInjected) return;
  window.__tvNaurokInjected = true;

  const D = window.tvDom;
  const S = window.tvScore;

  const state = {
    settings: null,
    questions: [],
    plan: null,
    running: false,
    hud: null,
    answersCache: new Map(),
    targetByQuestionIndex: null,
    observer: null,
    autoMode: false,
    totalQuestions: 0,
    currentIndex: 0,
  };

  function detectTotalAndIndex() {
    const cur = document.querySelector(".currentActiveQuestion");
    const total = document.querySelector('[ng-bind="test.document.questions"]');
    const c = cur ? parseInt(D.cleanText(cur.textContent), 10) : 0;
    const t = total ? parseInt(D.cleanText(total.textContent), 10) : 0;
    return { current: c || 0, total: t || 0 };
  }

  function parseCurrentQuestion() {
    const block = document.querySelector(".test-container-inner") ||
                  document.querySelector(".test-question-content")?.closest("[class*=container]") ||
                  document.querySelector(".test-screen") || document;

    const textNode = document.querySelector(".test-content-text-inner") ||
                     document.querySelector('[ng-bind-html="renderHtml(test.question.content)"]') ||
                     document.querySelector(".test-question-content .test-content-text");
    const text = textNode ? D.visibleText(textNode).slice(0, 1500) : "";

    const optsWrap = document.querySelector(".test-options-grid") ||
                     document.querySelector(".test-question-options");
    if (!optsWrap) return null;

    const optionItems = Array.from(optsWrap.querySelectorAll(".question-option-inner"));
    if (optionItems.length < 2) {
      const fb = Array.from(optsWrap.querySelectorAll(".test-option"));
      if (fb.length < 2) return null;
      return buildQuestion(text, fb, fb.map(el => D.visibleText(el)), block);
    }

    const options = optionItems.map((el) => {
      const c = el.querySelector(".question-option-inner-content");
      return D.visibleText(c || el).slice(0, 400);
    });

    return buildQuestion(text, optionItems, options, block);
  }

  function buildQuestion(text, optionElements, options, block) {
    if (!text && !options.length) return null;
    const images = D.imagesIn(block || document).slice(0, 3);
    const detect = detectTotalAndIndex();
    state.totalQuestions = detect.total || state.totalQuestions;
    state.currentIndex = detect.current || state.currentIndex;
    const idx = state.currentIndex || 0;
    const id = D.hash(text + "|" + options.join("|"));
    return {
      id,
      index: idx,
      element: block,
      optionElements,
      text,
      images,
      options,
    };
  }

  function detectTest() {
    const detect = detectTotalAndIndex();
    const q = parseCurrentQuestion();
    return { total: detect.total || (q ? 1 : 0), current: detect.current };
  }

  function buildHud() {
    if (state.hud) return state.hud;
    const root = document.createElement("div");
    root.className = "tv-hud";
    root.innerHTML = `
      <div class="tv-hud-head">
        <div class="tv-hud-title"><div class="tv-hud-dot"></div>IlyhaVision</div>
        <button class="tv-hud-close" title="Скрыть">×</button>
      </div>
      <div class="tv-hud-row"><span>Вопрос</span><b data-k="current">—</b></div>
      <div class="tv-hud-row"><span>Всего</span><b data-k="total">0</b></div>
      <div class="tv-hud-row"><span>Цель</span><b data-k="target">—</b></div>
      <div class="tv-progress"><div class="tv-progress-fill"></div></div>
      <div class="tv-hud-actions">
        <button class="tv-hud-btn" data-act="run">Подсветить</button>
        <button class="tv-hud-btn tv-hud-btn-ghost" data-act="auto">Авто</button>
      </div>`;
    document.body.appendChild(root);
    root.querySelector('[data-act="run"]').addEventListener("click", () => run(true));
    root.querySelector('[data-act="auto"]').addEventListener("click", toggleAuto);
    root.querySelector(".tv-hud-close").addEventListener("click", () => root.classList.add("tv-hud-hidden"));
    state.hud = root;
    return root;
  }

  function updateHud(patch) {
    if (!state.hud) buildHud();
    Object.entries(patch || {}).forEach(([k, v]) => {
      const el = state.hud.querySelector(`[data-k="${k}"]`);
      if (el) el.textContent = v;
    });
  }

  function setProgress(p) {
    if (!state.hud) return;
    const fill = state.hud.querySelector(".tv-progress-fill");
    if (fill) fill.style.width = Math.max(0, Math.min(100, p)) + "%";
  }

  function showToast(text, kind) {
    const t = document.createElement("div");
    t.className = "tv-toast tv-toast-" + (kind || "info");
    t.textContent = text;
    document.body.appendChild(t);
    requestAnimationFrame(() => t.classList.add("tv-toast-show"));
    setTimeout(() => {
      t.classList.remove("tv-toast-show");
      setTimeout(() => t.remove(), 400);
    }, 2800);
  }

  function applyMode() {
    document.documentElement.classList.toggle(
      "tv-stealth",
      state.settings && state.settings.mode === "stealth"
    );
  }

  function clearMarks() {
    document.querySelectorAll(".tv-mark").forEach((el) => {
      el.classList.remove("tv-mark", "tv-mark-correct", "tv-mark-wrong");
    });
  }

  function markOption(el, correct) {
    if (!el) return;
    el.classList.add("tv-mark", correct ? "tv-mark-correct" : "tv-mark-wrong");
  }

  function sendBg(type, payload) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type, payload }, (resp) => resolve(resp || {}));
    });
  }

  async function solveOne(q) {
    const cached = state.answersCache.get(q.id);
    if (cached) return cached;
    const payload = {
      site: "naurok",
      engine: state.settings.engine,
      questions: [{ id: q.id, text: q.text, options: q.options, images: q.images }],
    };
    const hasImages = q.images && q.images.length;
    const resp = await sendBg(hasImages ? "BG_VISION" : "BG_SOLVE", payload);
    if (!resp.ok) {
      if (resp.status === 402) throw new Error("Лимит запросов исчерпан");
      throw new Error(resp.error || "Ошибка AI");
    }
    const ans = (resp.data.answers || []).find((a) => a.id === q.id);
    if (ans) state.answersCache.set(q.id, ans);
    return ans;
  }

  function shouldBeCorrectForIndex(idx) {
    if (!state.settings) return true;
    const target = Math.min(state.settings.targetScore, state.totalQuestions || state.settings.totalScore || 12);
    const total = state.totalQuestions || state.settings.totalScore || 12;
    if (!state.targetByQuestionIndex || state.targetByQuestionIndex.size !== total) {
      state.targetByQuestionIndex = new Map();
      const order = [];
      for (let i = 0; i < total; i++) order.push(i);
      for (let i = order.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [order[i], order[j]] = [order[j], order[i]];
      }
      const correctSet = new Set(order.slice(0, target));
      for (let i = 0; i < total; i++) {
        state.targetByQuestionIndex.set(i, correctSet.has(i));
      }
    }
    return state.targetByQuestionIndex.get(idx) !== false;
  }

  async function run(manual) {
    if (state.running) return { ok: false, error: "уже работает" };
    state.running = true;
    clearMarks();
    try {
      const q = parseCurrentQuestion();
      if (!q) {
        if (manual) showToast("Вопрос не найден", "error");
        return { ok: false, error: "no question", count: 0 };
      }

      const detect = detectTotalAndIndex();
      state.totalQuestions = detect.total || state.totalQuestions;
      state.currentIndex = detect.current || state.currentIndex;
      const targetForHud = Math.min(state.settings.targetScore, state.totalQuestions || 12);
      updateHud({
        current: state.currentIndex || "—",
        total: state.totalQuestions || 1,
        target: targetForHud + " / " + (state.totalQuestions || 12),
      });

      const ans = await solveOne(q);
      if (!ans || typeof ans.correctIndex !== "number") {
        if (manual) showToast("AI не вернул ответ", "error");
        return { ok: false, error: "no answer" };
      }

      const qIdx = (state.currentIndex || 1) - 1;
      const shouldBeCorrect = shouldBeCorrectForIndex(qIdx);
      const targetIdx = shouldBeCorrect ? ans.correctIndex : S.pickWrongOption(q.options, ans.correctIndex);
      const optEl = q.optionElements[targetIdx];
      markOption(optEl, shouldBeCorrect);
      setProgress(100);
      if (manual) showToast("Ответ подсвечен", "success");
      return { ok: true, count: 1 };
    } catch (e) {
      if (manual) showToast(e.message || "Ошибка", "error");
      return { ok: false, error: e.message };
    } finally {
      state.running = false;
    }
  }

  function toggleAuto() {
    state.autoMode = !state.autoMode;
    const btn = state.hud && state.hud.querySelector('[data-act="auto"]');
    if (btn) {
      btn.textContent = state.autoMode ? "Авто ✓" : "Авто";
      btn.classList.toggle("tv-hud-btn-ghost", !state.autoMode);
    }
    showToast(state.autoMode ? "Авто-режим включён" : "Авто-режим выключен", "success");
    if (state.autoMode) scheduleAuto();
  }

  let autoTimer = null;
  function scheduleAuto() {
    if (autoTimer) clearTimeout(autoTimer);
    autoTimer = setTimeout(() => {
      if (state.autoMode) run(false);
    }, 600);
  }

  function startObserver() {
    if (state.observer) return;
    const target = document.querySelector(".test-container, .test-screen, body") || document.body;
    state.observer = new MutationObserver(() => {
      const detect = detectTotalAndIndex();
      if (detect.current !== state.currentIndex || detect.total !== state.totalQuestions) {
        state.totalQuestions = detect.total || state.totalQuestions;
        state.currentIndex = detect.current || state.currentIndex;
        updateHud({ current: state.currentIndex || "—", total: state.totalQuestions || 0 });
        if (state.autoMode) scheduleAuto();
      }
    });
    state.observer.observe(target, { childList: true, subtree: true, characterData: true });
  }

  async function loadSettings() {
    const data = await chrome.storage.local.get("tvSettings");
    state.settings = data.tvSettings || {
      mode: "normal",
      targetScore: 12,
      totalScore: 12,
      engine: "lite",
      autoRun: false,
      soundOn: false,
    };
    applyMode();
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "DETECT_TEST") {
      sendResponse(detectTest());
      return;
    }
    if (msg.type === "RUN_SCAN") {
      if (msg.settings) state.settings = msg.settings;
      applyMode();
      run(true).then((r) => sendResponse(r));
      return true;
    }
    if (msg.type === "SETTINGS_UPDATE") {
      state.settings = msg.settings;
      applyMode();
      state.targetByQuestionIndex = null;
      sendResponse({ ok: true });
      return;
    }
  });

  (async () => {
    await loadSettings();
    buildHud();
    const det = detectTest();
    state.totalQuestions = det.total;
    state.currentIndex = det.current;
    const tg = Math.min(state.settings.targetScore, det.total || 12);
    updateHud({
      current: det.current || "—",
      total: det.total || 0,
      target: tg + " / " + (det.total || state.settings.totalScore),
    });
    startObserver();
    if (det.total && state.settings.autoRun) {
      state.autoMode = true;
      const btn = state.hud && state.hud.querySelector('[data-act="auto"]');
      if (btn) {
        btn.textContent = "Авто ✓";
        btn.classList.remove("tv-hud-btn-ghost");
      }
      setTimeout(() => run(false), 1500);
    }
  })();
})();
