(() => {
  if (window.__tvNaurokInjected) return;
  window.__tvNaurokInjected = true;

  const D = window.tvDom;
  const S = window.tvScore;

  const state = {
    settings: null,
    questions: [],
    plan: null,
    running: false,
    hud: null,
  };

  function parseQuestions() {
    const byStrategy = [
      strategyRadioGroups,
      strategyClassSelectors,
      strategyListPatterns,
    ];
    for (const fn of byStrategy) {
      try {
        const out = fn();
        console.log("[TV] strategy", fn.name, "found", out.length);
        if (out.length) return out;
      } catch (e) {
        console.warn("[TV] strategy", fn.name, "error", e);
      }
    }
    return [];
  }

  function strategyRadioGroups() {
    const inputs = Array.from(document.querySelectorAll('input[type="radio"], input[type="checkbox"]'));
    const groups = new Map();
    inputs.forEach((inp) => {
      const key = inp.name || inp.getAttribute("data-question") || inp.closest("form,fieldset,[class*=question],[class*=task]")?.dataset.id || ("group_" + Math.random());
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(inp);
    });
    const result = [];
    let idx = 0;
    for (const [key, items] of groups) {
      if (items.length < 2) continue;
      const block = nearestCommonAncestor(items);
      if (!block) continue;
      const optionElements = items.map((inp) => labelFor(inp));
      const options = optionElements.map((el) => D.visibleText(el).slice(0, 400));
      const text = extractQuestionText(block, optionElements).slice(0, 1500);
      const images = D.imagesIn(block).slice(0, 3);
      result.push({
        id: D.hash(text + idx),
        index: idx++,
        element: block,
        optionElements,
        inputs: items,
        text,
        images,
        options,
      });
    }
    return result;
  }

  function strategyClassSelectors() {
    const found = [];
    const blocks = D.findAll(document, [
      "[class*=question-item]",
      "[class*=task-question]",
      "[class*=quiz-question]",
      "[data-question-id]",
      "div[class*=question]",
      "div[class*=task]",
    ]);
    blocks.forEach((block, idx) => {
      const optionEls = D.findAll(block, [
        "label",
        "[class*=answer]",
        "[class*=option]",
        "li",
      ]).filter((el) => {
        const t = D.visibleText(el);
        return t && t.length > 0 && t.length < 600;
      });
      if (optionEls.length < 2) return;
      const options = optionEls.map((el) => D.visibleText(el).slice(0, 400));
      const text = extractQuestionText(block, optionEls).slice(0, 1500);
      const images = D.imagesIn(block).slice(0, 3);
      found.push({
        id: D.hash(text + idx),
        index: idx,
        element: block,
        optionElements: optionEls,
        text,
        images,
        options,
      });
    });
    return found;
  }

  function strategyListPatterns() {
    const found = [];
    const forms = document.querySelectorAll("form");
    let idx = 0;
    forms.forEach((form) => {
      const groups = form.querySelectorAll("fieldset, ol, ul, .question, .test-question");
      groups.forEach((g) => {
        const opts = Array.from(g.querySelectorAll("label, li"));
        if (opts.length < 2) return;
        const options = opts.map((el) => D.visibleText(el).slice(0, 400));
        const text = extractQuestionText(g, opts).slice(0, 1500);
        if (!text) return;
        found.push({
          id: D.hash(text + idx),
          index: idx++,
          element: g,
          optionElements: opts,
          text,
          images: D.imagesIn(g).slice(0, 3),
          options,
        });
      });
    });
    return found;
  }

  function labelFor(input) {
    if (input.id) {
      const lbl = document.querySelector(`label[for="${CSS.escape(input.id)}"]`);
      if (lbl) return lbl;
    }
    const parentLabel = input.closest("label");
    if (parentLabel) return parentLabel;
    const wrap = input.parentElement;
    return wrap || input;
  }

  function nearestCommonAncestor(els) {
    if (!els.length) return null;
    let node = els[0].parentElement;
    while (node) {
      if (els.every((e) => node.contains(e))) return node;
      node = node.parentElement;
    }
    return null;
  }

  function extractQuestionText(block, optionEls) {
    const clone = block.cloneNode(true);
    optionEls.forEach((opt) => {
      const matching = clone.querySelectorAll(opt.tagName);
      matching.forEach((el) => {
        if (el.textContent.trim() === opt.textContent.trim()) el.remove();
      });
    });
    clone.querySelectorAll("input, button, script, style").forEach((n) => n.remove());
    return D.cleanText(clone.textContent);
  }

  function detectTest() {
    const qs = parseQuestions();
    return { total: qs.length };
  }

  function buildHud() {
    if (state.hud) return state.hud;
    const root = document.createElement("div");
    root.className = "tv-hud";
    root.innerHTML = `
      <div class="tv-hud-head">
        <div class="tv-hud-title"><div class="tv-hud-dot"></div>IlyhaVision</div>
        <button class="tv-hud-close" title="Скрыть">×</button>
      </div>
      <div class="tv-hud-row"><span>Найдено</span><b data-k="total">0</b></div>
      <div class="tv-hud-row"><span>Решено</span><b data-k="done">0</b></div>
      <div class="tv-hud-row"><span>Цель</span><b data-k="target">—</b></div>
      <div class="tv-progress"><div class="tv-progress-fill"></div></div>
      <div class="tv-hud-actions">
        <button class="tv-hud-btn" data-act="run">Запустить</button>
        <button class="tv-hud-btn tv-hud-btn-ghost" data-act="clear">Очистить</button>
      </div>`;
    document.body.appendChild(root);
    root.querySelector('[data-act="run"]').addEventListener("click", run);
    root.querySelector('[data-act="clear"]').addEventListener("click", clearMarks);
    root.querySelector(".tv-hud-close").addEventListener("click", () => root.classList.add("tv-hud-hidden"));
    state.hud = root;
    return root;
  }

  function updateHud(patch) {
    if (!state.hud) buildHud();
    Object.entries(patch || {}).forEach(([k, v]) => {
      const el = state.hud.querySelector(`[data-k="${k}"]`);
      if (el) el.textContent = v;
    });
  }

  function setProgress(p) {
    if (!state.hud) return;
    const fill = state.hud.querySelector(".tv-progress-fill");
    if (fill) fill.style.width = Math.max(0, Math.min(100, p)) + "%";
  }

  function showToast(text, kind) {
    const t = document.createElement("div");
    t.className = "tv-toast tv-toast-" + (kind || "info");
    t.textContent = text;
    document.body.appendChild(t);
    requestAnimationFrame(() => t.classList.add("tv-toast-show"));
    setTimeout(() => {
      t.classList.remove("tv-toast-show");
      setTimeout(() => t.remove(), 400);
    }, 2800);
  }

  function applyMode() {
    document.documentElement.classList.toggle(
      "tv-stealth",
      state.settings && state.settings.mode === "stealth"
    );
  }

  function clearMarks() {
    document.querySelectorAll(".tv-mark").forEach((el) => {
      el.classList.remove("tv-mark", "tv-mark-correct", "tv-mark-wrong");
    });
    setProgress(0);
    updateHud({ done: 0 });
  }

  function markOption(el, correct) {
    if (!el) return;
    el.classList.add("tv-mark", correct ? "tv-mark-correct" : "tv-mark-wrong");
  }

  function sendBg(type, payload) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type, payload }, (resp) => resolve(resp || {}));
    });
  }

  async function solveQuestions(qs) {
    const payload = {
      site: "naurok",
      engine: state.settings.engine,
      questions: qs.map((q) => ({
        id: q.id,
        text: q.text,
        options: q.options,
        images: q.images,
      })),
    };
    const hasImages = qs.some((q) => q.images && q.images.length);
    const resp = await sendBg(hasImages ? "BG_VISION" : "BG_SOLVE", payload);
    if (!resp.ok) {
      if (resp.status === 402) {
        throw new Error("Лимит запросов исчерпан");
      }
      throw new Error(resp.error || "Ошибка AI");
    }
    return resp.data.answers || [];
  }

  async function run() {
    if (state.running) return;
    state.running = true;
    clearMarks();
    try {
      const qs = parseQuestions();
      state.questions = qs;
      updateHud({ total: qs.length, done: 0 });
      if (!qs.length) {
        showToast("Вопросы не найдены", "error");
        return { ok: false, error: "no questions", count: 0 };
      }

      const target = Math.min(state.settings.targetScore, qs.length);
      const total = state.settings.totalScore || qs.length;
      const planned = S.planAnswers(qs, target, total);
      state.plan = planned;
      updateHud({ target: target + " / " + planned.total });

      const answers = await solveQuestions(qs);
      const byId = {};
      answers.forEach((a) => { byId[a.id] = a; });

      let done = 0;
      for (let i = 0; i < qs.length; i++) {
        const q = qs[i];
        const ans = byId[q.id];
        if (!ans || typeof ans.correctIndex !== "number") continue;
        const shouldBeCorrect = planned.plan[i].markCorrect;
        const targetIdx = shouldBeCorrect
          ? ans.correctIndex
          : S.pickWrongOption(q.options, ans.correctIndex);
        const optEl = q.optionElements[targetIdx];
        markOption(optEl, shouldBeCorrect);
        done++;
        updateHud({ done });
        setProgress((done / qs.length) * 100);
        await sleep(20);
      }

      showToast("Готово · " + done + " ответов", "success");
      return { ok: true, count: done };
    } catch (e) {
      showToast(e.message || "Ошибка", "error");
      return { ok: false, error: e.message };
    } finally {
      state.running = false;
    }
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  async function loadSettings() {
    const data = await chrome.storage.local.get("tvSettings");
    state.settings = data.tvSettings || {
      mode: "normal",
      targetScore: 12,
      totalScore: 12,
      engine: "lite",
      autoRun: false,
      soundOn: false,
    };
    applyMode();
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "DETECT_TEST") {
      sendResponse(detectTest());
      return;
    }
    if (msg.type === "RUN_SCAN") {
      if (msg.settings) state.settings = msg.settings;
      applyMode();
      run().then((r) => sendResponse(r));
      return true;
    }
    if (msg.type === "SETTINGS_UPDATE") {
      state.settings = msg.settings;
      applyMode();
      sendResponse({ ok: true });
      return;
    }
  });

  (async () => {
    await loadSettings();
    buildHud();
    const det = detectTest();
    updateHud({ total: det.total, target: state.settings.targetScore + " / " + (state.settings.totalScore || det.total) });
    if (det.total && state.settings.autoRun) {
      setTimeout(run, 800);
    }
  })();
})();
