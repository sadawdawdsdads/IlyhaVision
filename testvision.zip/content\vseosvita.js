(() => {
  if (window.__tvVseInjected) return;
  window.__tvVseInjected = true;

  const D = window.tvDom;
  const S = window.tvScore;

  const state = {
    settings: null,
    questions: [],
    plan: null,
    running: false,
    hud: null,
  };

  function parseQuestions() {
    const found = [];
    const blocks = D.findAll(document, [
      ".test-question",
      ".question-block",
      ".question",
      "[data-question]",
      "form .quiz-item",
    ]);

    blocks.forEach((block, idx) => {
      const textNode = D.findFirst(block, [
        ".question-title",
        ".question-text",
        ".test-question__text",
        "h3",
        "h4",
        "p",
      ]);
      const text = D.visibleText(textNode || block).slice(0, 1500);
      const images = D.imagesIn(block).slice(0, 3);
      const optionEls = D.findAll(block, [
        ".answer",
        ".test-answer",
        ".option",
        "label",
        "li",
      ]).filter((el) => {
        const t = D.visibleText(el);
        return t && t.length > 0 && t.length < 600;
      });
      const options = optionEls.map((el) => D.visibleText(el).slice(0, 400));
      if (!options.length) return;
      found.push({
        id: D.hash(text + idx),
        index: idx,
        element: block,
        optionElements: optionEls,
        text,
        images,
        options,
      });
    });

    return found;
  }

  function detectTest() {
    const qs = parseQuestions();
    return { total: qs.length };
  }

  function buildHud() {
    if (state.hud) return state.hud;
    const root = document.createElement("div");
    root.className = "tv-hud";
    root.innerHTML = `
      <div class="tv-hud-head">
        <div class="tv-hud-title"><div class="tv-hud-dot"></div>TestVision</div>
        <button class="tv-hud-close" title="Скрыть">×</button>
      </div>
      <div class="tv-hud-row"><span>Найдено</span><b data-k="total">0</b></div>
      <div class="tv-hud-row"><span>Решено</span><b data-k="done">0</b></div>
      <div class="tv-hud-row"><span>Цель</span><b data-k="target">—</b></div>
      <div class="tv-progress"><div class="tv-progress-fill"></div></div>
      <div class="tv-hud-actions">
        <button class="tv-hud-btn" data-act="run">Запустить</button>
        <button class="tv-hud-btn tv-hud-btn-ghost" data-act="clear">Очистить</button>
      </div>`;
    document.body.appendChild(root);
    root.querySelector('[data-act="run"]').addEventListener("click", run);
    root.querySelector('[data-act="clear"]').addEventListener("click", clearMarks);
    root.querySelector(".tv-hud-close").addEventListener("click", () => root.classList.add("tv-hud-hidden"));
    state.hud = root;
    return root;
  }

  function updateHud(patch) {
    if (!state.hud) buildHud();
    Object.entries(patch || {}).forEach(([k, v]) => {
      const el = state.hud.querySelector(`[data-k="${k}"]`);
      if (el) el.textContent = v;
    });
  }

  function setProgress(p) {
    if (!state.hud) return;
    const fill = state.hud.querySelector(".tv-progress-fill");
    if (fill) fill.style.width = Math.max(0, Math.min(100, p)) + "%";
  }

  function showToast(text, kind) {
    const t = document.createElement("div");
    t.className = "tv-toast tv-toast-" + (kind || "info");
    t.textContent = text;
    document.body.appendChild(t);
    requestAnimationFrame(() => t.classList.add("tv-toast-show"));
    setTimeout(() => {
      t.classList.remove("tv-toast-show");
      setTimeout(() => t.remove(), 400);
    }, 2800);
  }

  function applyMode() {
    document.documentElement.classList.toggle(
      "tv-stealth",
      state.settings && state.settings.mode === "stealth"
    );
  }

  function clearMarks() {
    document.querySelectorAll(".tv-mark").forEach((el) => {
      el.classList.remove("tv-mark", "tv-mark-correct", "tv-mark-wrong");
    });
    setProgress(0);
    updateHud({ done: 0 });
  }

  function markOption(el, correct) {
    if (!el) return;
    el.classList.add("tv-mark", correct ? "tv-mark-correct" : "tv-mark-wrong");
  }

  function sendBg(type, payload) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type, payload }, (resp) => resolve(resp || {}));
    });
  }

  async function solveQuestions(qs) {
    const payload = {
      site: "vseosvita",
      engine: state.settings.engine,
      questions: qs.map((q) => ({
        id: q.id,
        text: q.text,
        options: q.options,
        images: q.images,
      })),
    };
    const hasImages = qs.some((q) => q.images && q.images.length);
    const resp = await sendBg(hasImages ? "BG_VISION" : "BG_SOLVE", payload);
    if (!resp.ok) {
      if (resp.status === 402) {
        throw new Error("Лимит запросов исчерпан");
      }
      throw new Error(resp.error || "Ошибка AI");
    }
    return resp.data.answers || [];
  }

  async function run() {
    if (state.running) return;
    state.running = true;
    clearMarks();
    try {
      const qs = parseQuestions();
      state.questions = qs;
      updateHud({ total: qs.length, done: 0 });
      if (!qs.length) {
        showToast("Вопросы не найдены", "error");
        return { ok: false, error: "no questions", count: 0 };
      }

      const target = Math.min(state.settings.targetScore, qs.length);
      const total = state.settings.totalScore || qs.length;
      const planned = S.planAnswers(qs, target, total);
      state.plan = planned;
      updateHud({ target: target + " / " + planned.total });

      const answers = await solveQuestions(qs);
      const byId = {};
      answers.forEach((a) => { byId[a.id] = a; });

      let done = 0;
      for (let i = 0; i < qs.length; i++) {
        const q = qs[i];
        const ans = byId[q.id];
        if (!ans || typeof ans.correctIndex !== "number") continue;
        const shouldBeCorrect = planned.plan[i].markCorrect;
        const targetIdx = shouldBeCorrect
          ? ans.correctIndex
          : S.pickWrongOption(q.options, ans.correctIndex);
        const optEl = q.optionElements[targetIdx];
        markOption(optEl, shouldBeCorrect);
        done++;
        updateHud({ done });
        setProgress((done / qs.length) * 100);
        await sleep(20);
      }

      showToast("Готово · " + done + " ответов", "success");
      return { ok: true, count: done };
    } catch (e) {
      showToast(e.message || "Ошибка", "error");
      return { ok: false, error: e.message };
    } finally {
      state.running = false;
    }
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  async function loadSettings() {
    const data = await chrome.storage.local.get("tvSettings");
    state.settings = data.tvSettings || {
      mode: "normal",
      targetScore: 12,
      totalScore: 12,
      engine: "lite",
      autoRun: false,
      soundOn: false,
    };
    applyMode();
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "DETECT_TEST") {
      sendResponse(detectTest());
      return;
    }
    if (msg.type === "RUN_SCAN") {
      if (msg.settings) state.settings = msg.settings;
      applyMode();
      run().then((r) => sendResponse(r));
      return true;
    }
    if (msg.type === "SETTINGS_UPDATE") {
      state.settings = msg.settings;
      applyMode();
      sendResponse({ ok: true });
      return;
    }
  });

  (async () => {
    await loadSettings();
    buildHud();
    const det = detectTest();
    updateHud({ total: det.total, target: state.settings.targetScore + " / " + (state.settings.totalScore || det.total) });
    if (det.total && state.settings.autoRun) {
      setTimeout(run, 800);
    }
  })();
})();
