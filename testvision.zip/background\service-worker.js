const API_BASE = "https://api.testvision.app";

async function getToken() {
  const s = await chrome.storage.local.get("tvSession");
  return s.tvSession ? s.tvSession.token : null;
}

async function apiRequest(path, body, method) {
  const token = await getToken();
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = "Bearer " + token;
  const res = await fetch(API_BASE + path, {
    method: method || (body ? "POST" : "GET"),
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch {}
  if (!res.ok) {
    const e = new Error((data && data.error) || ("HTTP " + res.status));
    e.status = res.status;
    throw e;
  }
  return data;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "BG_SOLVE") {
    apiRequest("/ai/solve", msg.payload)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((e) => sendResponse({ ok: false, error: e.message, status: e.status }));
    return true;
  }
  if (msg.type === "BG_VISION") {
    apiRequest("/ai/vision", msg.payload)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((e) => sendResponse({ ok: false, error: e.message, status: e.status }));
    return true;
  }
  if (msg.type === "BG_USAGE") {
    apiRequest("/usage")
      .then((data) => sendResponse({ ok: true, data }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === "BG_NOTIFY") {
    chrome.action.setBadgeText({ text: msg.text || "" });
    chrome.action.setBadgeBackgroundColor({ color: msg.color || "#7c5cff" });
    sendResponse({ ok: true });
    return true;
  }
});

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.tabs.create({ url: "https://testvision.app/welcome" });
    chrome.storage.local.set({
      tvSettings: {
        mode: "normal",
        targetScore: 12,
        totalScore: 12,
        engine: "lite",
        autoRun: true,
        soundOn: false,
      },
    });
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || !tab.url) return;
  const isTarget =
    tab.url.includes("naurok.com.ua") || tab.url.includes("vseosvita.ua");
  if (isTarget) {
    chrome.action.setBadgeText({ tabId, text: "·" });
    chrome.action.setBadgeBackgroundColor({ tabId, color: "#7c5cff" });
  } else {
    chrome.action.setBadgeText({ tabId, text: "" });
  }
});
